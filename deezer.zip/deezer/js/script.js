/* Deezer JS 
    Coded by : Arthur DESMONTS
*/
